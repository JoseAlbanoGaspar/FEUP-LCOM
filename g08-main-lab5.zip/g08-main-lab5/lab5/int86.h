#ifndef _LCOM_INT86_H_
#define _LCOM_INT86_H_

#include <lcom/lcf.h>


#define VBE_CALL 0x4F
#define SET_VBE_MODE 0x02
#define INT_NO 0x10

#endif /* _LCOM_INT86_H */
